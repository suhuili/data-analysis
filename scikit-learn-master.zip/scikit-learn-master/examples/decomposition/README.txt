.. _decomposition_examples:

Decomposition
-------------

Examples concerning the :mod:`sklearn.decomposition` module.

